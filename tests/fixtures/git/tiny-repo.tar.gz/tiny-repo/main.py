"""Entry point for the tiny-repo fixture application."""

from __future__ import annotations

from core.pipeline import Pipeline


def setup() -> Pipeline:
    """Create and configure the processing pipeline."""
    return Pipeline(name="default", max_workers=4)


def run(pipeline: Pipeline) -> int:
    """Run the pipeline and return an exit code."""
    result = pipeline.execute()
    if result:
        return 0
    return 1


def main() -> None:
    """Main entry point."""
    pipeline = setup()
    code = run(pipeline)
    raise SystemExit(code)


if __name__ == "__main__":
    main()

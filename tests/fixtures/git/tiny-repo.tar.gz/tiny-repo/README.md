# tiny-repo

A minimal Python project used as a git-adapter test fixture for `contextd`.

Contains five source files with real function/class declarations, a README,
and a `.gitignore` that excludes `__pycache__/`. Not intended to run.

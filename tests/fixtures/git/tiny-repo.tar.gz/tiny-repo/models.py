"""Data models for the tiny-repo fixture."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    """Application configuration."""

    name: str
    max_workers: int = 4
    debug: bool = False


@dataclass(frozen=True)
class Result:
    """Processing result."""

    success: bool
    message: str
    items_processed: int = 0


@dataclass(frozen=True)
class Item:
    """A single work item."""

    id: str
    payload: str
    priority: int = 0

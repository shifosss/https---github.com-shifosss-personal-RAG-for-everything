"""Core pipeline module for the tiny-repo fixture."""

from __future__ import annotations


class Pipeline:
    """A minimal processing pipeline."""

    def __init__(self, name: str, max_workers: int = 4) -> None:
        self.name = name
        self.max_workers = max_workers
        self._items: list[str] = []

    def submit(self, item: str) -> None:
        """Queue an item for processing."""
        self._items.append(item)

    def execute(self) -> bool:
        """Run the pipeline and return success flag."""
        processed = 0
        for item in self._items:
            if self._process_one(item):
                processed += 1
        return processed == len(self._items)

    def _process_one(self, item: str) -> bool:
        """Process a single item."""
        return bool(item)

    def reset(self) -> None:
        """Clear the queue."""
        self._items = []

"""Utility helpers for the tiny-repo fixture."""

from __future__ import annotations

import hashlib


def slugify(text: str) -> str:
    """Convert text to a URL-safe slug."""
    return text.lower().replace(" ", "-").replace("_", "-")


def sha256_hex(data: bytes) -> str:
    """Return the SHA-256 hex digest of *data*."""
    return hashlib.sha256(data).hexdigest()


def chunk_list(items: list[str], size: int) -> list[list[str]]:
    """Split *items* into consecutive chunks of at most *size* elements."""
    return [items[i : i + size] for i in range(0, len(items), size)]

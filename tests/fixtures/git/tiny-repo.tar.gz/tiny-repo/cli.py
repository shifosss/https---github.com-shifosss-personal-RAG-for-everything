"""Command-line interface for the tiny-repo fixture."""

from __future__ import annotations

import argparse


def build_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser."""
    parser = argparse.ArgumentParser(
        prog="tiny-repo",
        description="Tiny fixture CLI for contextd tests",
    )
    parser.add_argument("--name", default="default", help="Pipeline name")
    parser.add_argument("--workers", type=int, default=4, help="Worker count")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    return parser


def run_cli() -> None:
    """Parse args and run the pipeline."""
    parser = build_parser()
    args = parser.parse_args()
    from core.pipeline import Pipeline

    pipeline = Pipeline(name=args.name, max_workers=args.workers)
    pipeline.execute()
